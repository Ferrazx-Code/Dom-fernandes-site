#!/bin/sh
# Rode dentro desta pasta, com a chave SSH da conta Ferrazx-Code configurada.
git init -b main
git add .
git commit -m "Site da Barbearia Dom Fernandes"
git remote add origin git@github.com:Ferrazx-Code/Dom-fernandes-site.git
git push -u origin main
